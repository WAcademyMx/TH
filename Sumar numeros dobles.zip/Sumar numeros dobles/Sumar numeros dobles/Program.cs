﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sumar_numeros_dobles
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            double suma;
          
            Console.WriteLine("INgres un numero, puede tener decimales");
            x = Double.Parse(Console.ReadLine());

            Console.WriteLine("INgresa un segundo numero");
            y = Double.Parse(Console.ReadLine());

            suma = x + y;

            Console.WriteLine("La suma es " + suma);
            Console.ReadKey();
        }
    }
}
