﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iteracion01
{
    class Program
    {
        static void Main(string[] args)
        {
        
            double c1, c2, c3; // Variable para cada un de las cal.
            double sc=0; // Suma de las calificaciones
            double p;  // promedio individual
            double sp = 0; // Suma de todos los promedios;
            double pg; // promedio general.
            int aa=0, ar=0;
            int N = 2;

            
            // Por cadauno de los 10 valores
            for (int i = 0; i < N; i++)
            {
                // SOlicitar las calificaciones
                Console.WriteLine("Ingresa la primera calificacion");
                c1 = Double.Parse(Console.ReadLine());
                Console.WriteLine("Ingresa la segunda calificacion");
                c2 = Double.Parse(Console.ReadLine());
                Console.WriteLine("Ingresa la tercera calificacion");
                c3 = Double.Parse(Console.ReadLine());

                // Sumar las calificaciones 
                sc = c1 + c2 + c3;
                // Calcular el promedio individua
                p = sc / 3;
                // Acumular el promedio individual
                sp = p + sp;
               // Determinar si el alumno es aprobado
               if(p>=6)
                {
                    aa++;
                }
               else
                {
                    ar++;
                }
                Console.WriteLine("el promedio de este alumno es " + p.ToString());
                             
            }
            // Calcular el promedio general
            pg = sp / N;
            // Mostrar los indicadores 
            Console.WriteLine("EL proemdio generall es " + pg.ToString());
            Console.WriteLine("Aprobados " + aa.ToString());
            Console.WriteLine("Reprobados " + ar.ToString());
            
            Console.Write("Presiona una tecla para terminar");
            Console.ReadKey();

        }
    }
}
