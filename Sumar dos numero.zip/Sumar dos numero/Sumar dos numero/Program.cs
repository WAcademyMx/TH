﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sumar_dos_numero
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            int suma;

            Console.WriteLine("Ingresa el primer numero");
            x = Int32.Parse(Console.ReadLine());

            Console.WriteLine("INgresa el segundo numero");
            y = Int32.Parse(Console.ReadLine());
            suma = x + y;

            Console.WriteLine(suma);

            Console.ReadKey();

        }
    }
}
