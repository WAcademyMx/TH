﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operaciones_enteros
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            int suma, resta, mul, div;

            Console.WriteLine("Ingresa el primer numero");
            x = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Ingresa el segundo numero");
            y = Int32.Parse(Console.ReadLine());

            suma = x + y;
            resta = x - y;
            mul = x * y;
            div = x / y;

            Console.WriteLine("EL valor de la suma es " + suma);
            Console.WriteLine("El valor de la resta es " + resta);
            Console.WriteLine("EL valor de la multiplicacion es " + mul);
            Console.WriteLine("El valor de la division es " + div);

            Console.ReadKey();

        }
    }
}
